To test the example plugins from the command prompt, go into which ever example folder you would like to test, and then type:

forward -L BodyDrag -S forward.xml

Then compare the output to that in the ExpectedResults.